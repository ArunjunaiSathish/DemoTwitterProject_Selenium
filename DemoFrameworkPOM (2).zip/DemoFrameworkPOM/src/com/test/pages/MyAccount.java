package com.test.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.test.wrappers.GenericWrappers;

public class MyAccount extends GenericWrappers {
	
	@FindBy(how = How.XPATH,using ="//a[contains(text(),' John ')]")
	private WebElement selectUserName;
	@FindBy(how = How.XPATH,using ="//a[contains(text(),'  Logout')]")
	private WebElement linkLogout;
	@FindBy(how = How.NAME,using = "username")
	private WebElement textUserNameField;
	
	public MyAccount(WebDriver driver) {
		this.driver = driver;
	}

	public LoginPage Logout() {
		selectUserName.click();
		wait("visibilityOfElementLocated",linkLogout);
		linkLogout.click();
		wait("visibilityOfElementLocated",textUserNameField);
		return PageFactory.initElements(driver, LoginPage.class);
	}

}
