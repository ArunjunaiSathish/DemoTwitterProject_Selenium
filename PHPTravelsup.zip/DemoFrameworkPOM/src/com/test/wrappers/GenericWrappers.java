
/**
 * @Title - Selenium Automation Framework - Hybrid Framework with POM / PageFactory
 * This class covers all the generic methods in application
 * Copyright(c) - 2017-2018
 * Start-Date - 01/05/2017
 */

package com.test.wrappers;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;

/**
 * @author Arunjunai Sathis R
 * @version 1.0  05 Jan 2017 
 * @see com.test.wrappers.GenericWrappers
 */

public class GenericWrappers {
	/**
	 * This is the variable for driver instance to use across tests 
	 */
	protected static WebDriver driver;
	/**
	 * This is the variable for storing window handle of browser 
	 */
	private String primaryWindowHandle;

	/**
	 * This method verifies that browser window exist or not 
	 * @return boolean 
	 * @see com.test.wrappers.GenericWrappers#verifyBrowser()
	 */
	public boolean verifyBrowser() {
		boolean bflag = false;
		primaryWindowHandle = driver.getWindowHandle();
		if(!primaryWindowHandle.equals(null)){
			bflag = true;
		}
		return bflag;
	}

	public void clickByXpath(String xpathValue) {
		String xpathval = xpathValue;
		try{
			driver.findElement(By.xpath(xpathval)).click();
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

	public void enterByName(String name,String value) {
		try{
			driver.findElement(By.name(name)).clear();
			driver.findElement(By.name(name)).sendKeys(value);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void clickByID(String id) {
		try{
			driver.findElement(By.id(id)).click();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public void clickByName(String name) {
		try{
			driver.findElement(By.name(name)).click();
		}
		catch(Exception e)
		{
			e.printStackTrace();	
		}
	}


	public void wait(String condition, WebElement elementToWait) {
		WebDriverWait wait = new WebDriverWait(driver, 40);
		try{
			switch(condition){
			case "visibilityOfElementLocated":
				wait.until(ExpectedConditions.visibilityOf(elementToWait));
				break;
			case "invisibilityOfElementLocated":
				wait.until(ExpectedConditions.invisibilityOfElementLocated((By) elementToWait));
				break;
			default:
				break;
			}
		}
		catch(Exception e){
			throw e;
		}

	}
	public void wait(String condition, By elementToWait) {
		WebDriverWait wait = new WebDriverWait(driver, 40);
		switch(condition){
		case "invisibilityOfElementLocated":
			wait.until(ExpectedConditions.invisibilityOfElementLocated(elementToWait));
			break;
		default:
			break;
		}

	}
	public WebElement fluentWait(final WebElement e) {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(10, TimeUnit.SECONDS)
				.pollingEvery(2, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		WebElement foo = wait.until(new Function<WebDriver, WebElement>() {

			public WebElement apply(WebDriver driver) {
				return e;
			}
		});

		return foo;
	};

	public void waitForPageLoad(){
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>(){

			public Boolean apply(WebDriver arg0) {

				return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(expectation);
	}

	public String fetchText(String xpathValue){
		String fetchValue = "";
		try{
			fetchValue = driver.findElement(By.xpath(xpathValue)).getText();	
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return fetchValue;
	}

}



