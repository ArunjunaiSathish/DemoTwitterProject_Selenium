package com.test.utils;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import org.testng.Reporter;

public class Retry implements IRetryAnalyzer{
	private int retryCount = 0;
	private int maxRetryCount = 3;

	// Below method returns 'true' if the test method has to be retried else 'false' 
	//and it takes the 'Result' as parameter of the test method that just ran
	public boolean retry(ITestResult result) {

		if(!result.isSuccess()){
			if (retryCount < maxRetryCount) {
				Reporter.log(result.getName()+"tried"+(retryCount+1)+"times", false);
				result.setStatus(ITestResult.FAILURE);
				retryCount++;
				return true;
			}	
			else{
				result.setStatus(ITestResult.FAILURE);	
			}
		}
		else{
			result.setStatus(ITestResult.SUCCESS);	
		}

		return false;
	}


}


