package com.test.utils;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import com.test.wrappers.GenericWrappers;

public class DataInputProvider extends GenericWrappers{

	public static String[][] getSheet(String sheetName){
		String[][] data = null;
		//System.out.println(sheetName);
		FileInputStream fin = null;
		XSSFWorkbook workBook = null;
		XSSFSheet sheet = null;
		try {

			try{
				fin = new FileInputStream(new File("./data/"+sheetName+".xlsx"));
				workBook = new XSSFWorkbook(fin);
				sheet = workBook.getSheetAt(0);

			}catch(Exception e){
				System.out.println("error here");
				System.out.println(e.getMessage());
			}

			int rowCount = sheet.getLastRowNum();
			//	int totalRows = rowCount - sheet.getFirstRowNum();
			int colCount = sheet.getRow(0).getLastCellNum();
			data = new String[rowCount][colCount];

			for(int i=1;i<rowCount+1;i++){
				try{
					XSSFRow row = sheet.getRow(i);
					for(int j=0;j<colCount;j++){
						try{
							String cellValue = "";
							try{
								cellValue = row.getCell(j).getStringCellValue();
							}
							catch(NullPointerException e){
								e.printStackTrace();
							}
							data[i-1][j] = cellValue;
						//	System.out.println(data[i-1][j]);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}

				}
				catch(Exception e){
					e.printStackTrace();
				}
	}
			workBook.close();
			fin.close();

		}catch(Exception e){
			e.printStackTrace();
		}
		return data;
	}
}