package com.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.test.wrappers.GenericWrappers;

public class HomePage extends GenericWrappers{

	WebDriver driver;
	@FindBy(how=How.XPATH,using="//a[contains(text(),' My Account ')]")
	private WebElement myAccountOption;

	@FindBy(how=How.XPATH,using="//a[contains(text(),'  Login')]")
	private WebElement loginOption;

	@FindBy(how=How.XPATH,using="//a[contains(text(),'  Sign Up')]")
	private WebElement signUpOption;

	@FindBy(how=How.XPATH,using="(//a[@class='dropdown-toggle'])[1]")
	private WebElement selectLanguage;

	@FindBy(how=How.XPATH,using="//a[contains(text(),'  English')]")
	private WebElement selectLanguageOption;

	@FindBy(how=How.ID,using="currency")
	private WebElement selectCurrency;

	@FindBy(how=How.LINK_TEXT,using=" Flights                ")
	private WebElement selectFlightsMenu;

	@FindBy(how=How.XPATH,using=" Tours                  ")
	private WebElement selectToursMenu;


	public HomePage(WebDriver driver){
		this.driver = driver;
	}


	public LoginPage loginOperation() throws InterruptedException{
			myAccountOption.click();
			fluentWait(loginOption);
			loginOption.click();
			waitForPageLoad();
			return PageFactory.initElements(driver, LoginPage.class);
	}

	public HomePage selectLanguage(){
		if(!selectLanguage.getText().equals("English")){
			selectLanguage.click();
			wait("visibilityOfElementLocated",selectLanguageOption);
			selectLanguageOption.click();
		}
		return this;
	}



}
