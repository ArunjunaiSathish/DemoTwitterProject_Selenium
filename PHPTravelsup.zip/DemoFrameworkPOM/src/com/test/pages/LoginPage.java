package com.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.test.wrappers.GenericWrappers;

public class LoginPage extends GenericWrappers {

	@FindBy(how = How.NAME,using = "username")
	private WebElement textUserNameField;
	
	@FindBy(how = How.NAME,using = "password")
	private WebElement textPassWordField;
	
	By buttonLoginLocator = By.xpath("//button[contains(text(),'Login')]");
	
	@FindBy(how = How.XPATH,using = "//button[contains(text(),'Login')]")
	private WebElement buttonLogin;
	
	public LoginPage(WebDriver driver){
		this.driver = driver;
	}
	
	public MyAccount loginApplication(String userName,String passWord) throws InterruptedException{
		wait("visibilityOfElementLocated",textUserNameField);
		textUserNameField.sendKeys(userName);
		wait("visibilityOfElementLocated",textPassWordField);
		textPassWordField.sendKeys(passWord);
		buttonLogin.click();
		wait("invisibilityOfElementLocated",buttonLoginLocator);
		return PageFactory.initElements(driver, MyAccount.class);
	}


	
	
}
