package com.test.scenarios;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.test.pages.HomePage;
import com.test.pages.LoginPage;
import com.test.pages.MyAccount;
import com.test.utils.DataInputProvider;
import com.test.utils.ScreenshotCapturer;
import com.test.wrappers.GenericWrappers;


public class VerifyLogin extends GenericWrappers{

	private HomePage page;
	
	@BeforeSuite
	public void environmentSetUp(){
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\zk3l0xp\\Downloads\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		options.addArguments("--disable-extensions");
		driver = new ChromeDriver(options);
		driver.get("http://phptravels.net/");
	}

	
	
	@BeforeTest()
	public void driverInit(){
		page = PageFactory.initElements(driver, HomePage.class);
	}

	@Test(priority=0)
	public void verifyLanguageSelected(){
		Reporter.log("Verifying Language in Home page", false);
		HomePage selectLanguage = page.selectLanguage();		
		Reporter.log("Language verification completed", false);
	}

	@Test(dataProvider = "fetchData")
	public void verifyLoginLogoutOperation(String UserName,String PassWord) throws InterruptedException {
			Reporter.log("Login Operation started", false);
			LoginPage loginPage = page.loginOperation();
			MyAccount accountPage = loginPage.loginApplication(UserName, PassWord);
			LoginPage loginPageAfterLogout = accountPage.Logout();
			Reporter.log("Logout Operation completed", false);
	}

	@AfterMethod
	public void reportingTestStatus(ITestResult result){
		if(result.getStatus() == ITestResult.FAILURE){
			com.test.utils.Reporter.
			
		}
	}
	
	@DataProvider(name="fetchData")
	public static Object[][] getData(){
		return DataInputProvider.getSheet("TestData");
	}

	@AfterSuite
	public void closeBrowser(){
		driver.quit();
	}

}
